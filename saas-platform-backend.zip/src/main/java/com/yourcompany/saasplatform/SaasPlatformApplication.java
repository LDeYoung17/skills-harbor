package com.yourcompany.saasplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaasPlatformApplication {
    public static void main(String[] args) {
        SpringApplication.run(SaasPlatformApplication.class, args);
    }
}